Pakin Panawattanakul 6580043
in this version if the time is exactly the same it will show 24 hours